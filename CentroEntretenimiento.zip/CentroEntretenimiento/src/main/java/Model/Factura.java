/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Control.Pago;

/**
 *
 * @author Alima
 */
public class Factura {
    String fecha;
    int numeroFactura;
    Cliente cliente;
    String mesPaga;
    double valorpagado;
    Servicio servicio;
    String formaDePago;
    Empleado cajero;
    
}
